#!/bin/bash

while true
do
./wildrig-multi --algo kawpow --url stratum+tcp://pool.woolypooly.com:55555 --worker test --user RQKDR2JXqtaqv6guzuGGWZsBXbmvhbZGBh --pass x
sleep 5
done
